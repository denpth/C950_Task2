# Student ID: 011690596
from routing import Main

if __name__ == '__main__':
    app = Main()
    app.run()
